export PS1='$ '
