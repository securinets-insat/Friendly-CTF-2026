# Deploy

1. `cp config/secrets.example.yml config/secrets.yml`
2. Fill in the values from the vault (ask ops).
3. `flask run`

> 2026-01-23: all production credentials were rotated. The old master token in
> `config/keys/legacy_api.key` is expired and kept only for the v1 client shim.
