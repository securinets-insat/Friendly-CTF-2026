from flask import Flask
app = Flask(__name__)

@app.route("/health")
def health():
    return {"status": "ok"}


@app.route("/shipment/<sid>")
def shipment(sid):
    return {"id": sid, "status": "in_transit"}
