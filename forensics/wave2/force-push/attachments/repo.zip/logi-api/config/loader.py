import yaml, pathlib

def load(name):
    return yaml.safe_load((pathlib.Path(__file__).parent / name).read_text())
